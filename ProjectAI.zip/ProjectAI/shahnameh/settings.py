import os
from pydantic import BaseSettings

class Settings(BaseSettings):
    # تنظیمات پایگاه داده
    DB_NAME: str = os.getenv("DB_NAME", "default_db")
    DB_USER: str = os.getenv("DB_USER", "default_user")
    DB_PASSWORD: str = os.getenv("DB_PASSWORD", "default_password")
    DB_HOST: str = os.getenv("DB_HOST", "localhost")
    DB_PORT: int = int(os.getenv("DB_PORT", 3306))

    # تنظیمات امنیتی
    SECRET_KEY: str = os.getenv("SECRET_KEY", "your-secret-key")
    JWT_SECRET_KEY: str = os.getenv("JWT_SECRET_KEY", "your-jwt-secret-key")
    ALGORITHM: str = os.getenv("ALGORITHM", "HS256")

    # تنظیمات محیط اجرا
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "development")
    DEBUG: bool = os.getenv("DEBUG", "True").lower() == "true"

    # سایر تنظیمات
    PROJECT_NAME: str = "Shahnameh Smart"
    API_VERSION: str = "v1"

# ایجاد یک نمونه از تنظیمات
settings = Settings()