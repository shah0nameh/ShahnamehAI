"""
Shahnameh Project
This package serves as the main entry point for the Shahnameh project.
"""

# Import necessary components for initialization
from app.main import app  # Import the main Flask application