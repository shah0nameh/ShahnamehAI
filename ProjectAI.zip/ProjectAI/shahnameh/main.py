from flask import Flask, render_template, request, redirect, url_for
from models import db, Poem
import json
import os

# تنظیمات برنامه Flask
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data/javidan.db'  # پایگاه داده SQLite
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# مقداردهی اولیه SQLAlchemy
db.init_app(app)

# مسیر فایل‌های JSON برای داده‌های کمکی
POEMS_FILE = 'data/poems.json'

# توابع کمکی برای مدیریت فایل‌های JSON
def load_data(file_path):
    """داده‌ها را از فایل JSON بارگذاری می‌کند."""
    if os.path.exists(file_path):
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return []

def save_data(file_path, data):
    """داده‌ها را در فایل JSON ذخیره می‌کند."""
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

# مسیر صفحه اصلی
@app.route('/')
def home():
    """نمایش صفحه اصلی."""
    return render_template('index.html')

# مسیر لیست داستان‌ها
@app.route('/poems')
def poems():
    """نمایش لیست اشعار (از پایگاه داده)."""
    poems = Poem.query.all()  # بازیابی داده‌ها از پایگاه داده
    return render_template('poems.html', poems=poems)

# مسیر ارسال شعر جدید
@app.route('/submit', methods=['GET', 'POST'])
def submit():
    """مسیر ارسال شعر جدید."""
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        # ذخیره در پایگاه داده
        new_poem = Poem(title=title, content=content)
        db.session.add(new_poem)
        db.session.commit()

        # اختیاری: ذخیره در فایل JSON به عنوان بکاپ
        poems = load_data(POEMS_FILE)
        poems.append({'title': title, 'content': content})
        save_data(POEMS_FILE, poems)

        return redirect(url_for('poems'))
    return render_template('submit.html')

# ایجاد جداول پایگاه داده در اولین اجرا
if __name__ == '__main__':
    # اطمینان از ایجاد جداول پایگاه داده
    with app.app_context():
        db.create_all()

    # اجرای برنامه
    app.run(debug=True)
    from fastapi import FastAPI
from app.errors.handlers import base_error_handler, not_found_error_handler, validation_error_handler
from app.errors.custom_errors import BaseAppError, NotFoundError, ValidationError

app = FastAPI()

# ثبت هندلرهای خطا
app.add_exception_handler(BaseAppError, base_error_handler)
app.add_exception_handler(NotFoundError, not_found_error_handler)
app.add_exception_handler(ValidationError, validation_error_handler)
from fastapi import FastAPI
from app.middlewares.authentication import authentication_middleware
from app.middlewares.logging import logging_middleware
from app.middlewares.error_handling import error_handling_middleware
from app.config.settings import settings

app = FastAPI(title=settings.APP_NAME, version=settings.VERSION)

# ثبت میان‌افزارها
app.middleware("http")(logging_middleware)
app.middleware("http")(error_handling_middleware)
app.middleware("http")(authentication_middleware)

@app.get("/")
def read_root():
    return {"message": "Welcome to Shahnameh AI"}