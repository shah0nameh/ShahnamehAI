export function initChat() {
    const button = document.querySelector("button");
    const textarea = document.querySelector("textarea");

    if (button && textarea) {
        button.addEventListener("click", () => {
            if (textarea.value.trim() !== "") {
                alert("پیام شما ارسال شد!");
                textarea.value = "";
            } else {
                alert("لطفاً پیام خود را وارد کنید.");
            }
        });
    }
}