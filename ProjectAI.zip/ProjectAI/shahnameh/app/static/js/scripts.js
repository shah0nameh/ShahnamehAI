// مدیریت نوار اعلان
const banner = document.querySelector(".scrolling-banner p");
setInterval(() => {
    banner.textContent = "از قابلیت‌های جدید سایت ما بهره ببرید!";
}, 15000);

// ارسال پیام در گفتگوی آنلاین
document.querySelector("button").addEventListener("click", () => {
    const textarea = document.querySelector("textarea");
    if (textarea.value.trim() !== "") {
        alert("پیام شما ارسال شد!");
        textarea.value = "";
    } else {
        alert("لطفاً پیام خود را وارد کنید.");
    }
});

// Lazy Loading برای تصاویر (در صورت وجود)
document.addEventListener("DOMContentLoaded", () => {
    const lazyImages = document.querySelectorAll("img[data-src]");
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                observer.unobserve(img);
            }
        });
    });

    lazyImages.forEach(img => {
        imageObserver.observe(img);
    });
});