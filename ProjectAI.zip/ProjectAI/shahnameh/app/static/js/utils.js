// static/js/utils.js

/**
 * تبدیل تاریخ به فرمت خوانا.
 * @param {string} date - تاریخ به صورت ISO
 * @returns {string} - تاریخ به صورت فرمت محلی
 */
export function formatDate(date) {
    return new Date(date).toLocaleDateString('fa-IR');
}

/**
 * تولید یک شناسه یکتا
 * @returns {string} - شناسه یکتا
 */
export function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = (Math.random() * 16) | 0;
        const v = c === 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
    });
}