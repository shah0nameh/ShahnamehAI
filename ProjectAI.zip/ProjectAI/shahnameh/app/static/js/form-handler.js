// static/js/modules/form-handler.js

/**
 * مدیریت ارسال فرم
 */
export function handleFormSubmit(formId) {
    const form = document.getElementById(formId);

    if (form) {
        form.addEventListener("submit", (event) => {
            event.preventDefault();
            const formData = new FormData(form);
            console.log("Form Data Submitted:", Object.fromEntries(formData));
            alert("فرم با موفقیت ارسال شد!");
        });
    }
}