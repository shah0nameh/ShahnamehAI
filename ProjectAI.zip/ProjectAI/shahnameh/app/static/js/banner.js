/**
 * مدیریت نوار اعلان
 */
export function initBanner() {
    const banner = document.querySelector(".scrolling-banner p");
    if (banner) {
        setInterval(() => {
            banner.textContent = "از قابلیت‌های جدید سایت