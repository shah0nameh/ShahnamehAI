import { fetchData } from "./api.js";
import { initBanner } from "./banner.js";
import { initChat } from "./chat.js";
import { initLazyLoading } from "./lazyload.js";

document.addEventListener("DOMContentLoaded", () => {
    // مقداردهی اولیه نوار اعلان
    initBanner();

    // مقداردهی اولیه گفتگوی آنلاین
    initChat();

    // مقداردهی اولیه Lazy Loading
    initLazyLoading();

    // نمونه فراخوانی API
    fetchData('/api/example-endpoint')
        .then(data => console.log("API Data:", data))
        .catch(error => console.error("Error:", error));
});