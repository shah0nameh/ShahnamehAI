from app.models.user import User
from app.schemas.user_schema import UserCreate, UserRead
from app.database import db_session

class UserService:
    @staticmethod
    def create_user(user_data: UserCreate) -> UserRead:
        new_user = User(
            username=user_data.username,
            email=user_data.email,
            password=user_data.password  # هش کردن رمز عبور انجام شود
        )
        db_session.add(new_user)
        db_session.commit()
        db_session.refresh(new_user)
        return UserRead.from_orm(new_user)

    @staticmethod
    def get_user_by_id(user_id: int) -> UserRead | None:
        user = db_session.query(User).filter(User.id == user_id).first()
        if user:
            return UserRead.from_orm(user)
        return None