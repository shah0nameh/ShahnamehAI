from app.models.poem import Poem
from app.schemas.poem_schema import PoemCreate, PoemResponse
from app.database import db_session

class PoemService:
    @staticmethod
    def create_poem(poem_data: PoemCreate) -> PoemResponse:
        new_poem = Poem(
            title=poem_data.title,
            body=poem_data.body,
            author_id=poem_data.author_id
        )
        db_session.add(new_poem)
        db_session.commit()
        db_session.refresh(new_poem)
        return PoemResponse.from_orm(new_poem)

    @staticmethod
    def get_all_poems() -> list[PoemResponse]:
        poems = db_session.query(Poem).all()
        return [PoemResponse.from_orm(poem) for poem in poems]