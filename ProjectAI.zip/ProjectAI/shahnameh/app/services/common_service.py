class CommonService:
    @staticmethod
    def format_pagination(page: int, size: int, total: int) -> dict:
        return {
            "page": page,
            "size": size,
            "total": total,
            "pages": (total + size - 1) // size
        }