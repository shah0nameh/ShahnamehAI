from fastapi import Request
from fastapi.responses import JSONResponse
from app.errors.custom_errors import BaseAppError, NotFoundError, ValidationError

def base_error_handler(request: Request, exc: BaseAppError):
    return JSONResponse(
        status_code=400,
        content={"error": exc.message}
    )

def not_found_error_handler(request: Request, exc: NotFoundError):
    return JSONResponse(
        status_code=404,
        content={"error": exc.message}
    )

def validation_error_handler(request: Request, exc: ValidationError):
    return JSONResponse(
        status_code=422,
        content={"error": exc.message}
    )