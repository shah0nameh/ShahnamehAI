class BaseAppError(Exception):
    """خطای پایه برای همه استثناهای سفارشی پروژه."""
    def __init__(self, message: str):
        self.message = message
        super().__init__(self.message)


class NotFoundError(BaseAppError):
    """خطا برای وقتی که یک منبع پیدا نشود."""
    def __init__(self, resource: str):
        message = f"{resource} not found"
        super().__init__(message)


class ValidationError(BaseAppError):
    """خطا برای مشکلات اعتبارسنجی."""
    def __init__(self, details: str):
        message = f"Validation error: {details}"
        super().__init__(message)