from pydantic import BaseSettings

class Settings(BaseSettings):
    APP_NAME: str = "Shahnameh AI"
    DEBUG: bool = True
    VERSION: str = "1.0.0"
    SECRET_KEY: str

    class Config:
        env_file = ".env"

settings = Settings()

from pydantic import BaseSettings

class Settings(BaseSettings):
    # تنظیمات عمومی
    APP_NAME: str = "Shahnameh AI"           # نام پروژه
    DEBUG: bool = True                       # حالت دیباگ
    VERSION: str = "1.0.0"                   # نسخه پروژه
    SECRET_KEY: str                          # کلید امنیتی
    ALLOWED_HOSTS: list[str] = ["*"]         # لیست هاست‌های مجاز

    # تنظیمات پایگاه داده
    DATABASE_URL: str                        # آدرس پایگاه داده

    # تنظیمات JWT
    JWT_ALGORITHM: str = "HS256"             # الگوریتم JWT
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30    # مدت زمان اعتبار توکن

    # تنظیمات ایمیل
    EMAIL_HOST: str = "smtp.example.com"     # هاست SMTP
    EMAIL_PORT: int = 587                    # پورت SMTP
    EMAIL_USERNAME: str                      # نام کاربری ایمیل
    EMAIL_PASSWORD: str                      # رمز عبور ایمیل
    EMAIL_FROM: str = "no-reply@example.com" # آدرس فرستنده ایمیل

    # مسیرهای ثابت
    STATIC_PATH: str = "./static"            # مسیر فایل‌های ثابت
    TEMPLATES_PATH: str = "./templates"      # مسیر قالب‌ها

    class Config:
        env_file = ".env"                    # فایل تنظیمات محیطی

settings = Settings()