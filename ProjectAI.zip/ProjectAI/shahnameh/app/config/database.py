from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from app.config.settings import settings

DATABASE_URL = "sqlite:///./shahnameh.db"  # آدرس پیش‌فرض پایگاه داده
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from app.config.settings import settings

# اتصال به پایگاه داده
engine = create_engine(settings.DATABASE_URL, connect_args={"check_same_thread": False})

# مدیریت نشست‌ها
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# تعریف مدل پایه
Base = declarative_base()