from .base_model import db

# مثال: رابطه چند به چند بین کاربران و داستان‌ها
likes = db.Table('likes',
    db.Column('user_id', db.Integer, db.ForeignKey('users.id'), primary_key=True),
    db.Column('poem_id', db.Integer, db.ForeignKey('poems.id'), primary_key=True)
)