from .base_model import BaseModel, db

class Poem(BaseModel):
    __tablename__ = 'poems'

    title = db.Column(db.String(150), nullable=False)
    content = db.Column(db.Text, nullable=False)
    author_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)

    def __repr__(self):
        return f"<Poem {self.title}>"