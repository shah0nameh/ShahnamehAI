from sqlalchemy import Column, Integer, String, DECIMAL
from database.connection import Base

class Product(Base):
    """
    مدل محصول که اطلاعات محصولات فروشگاه را نگهداری می‌کند.
    شامل مشخصاتی مانند نام، توضیحات، قیمت و موجودی (stock).
    """
    __tablename__ = 'products'

    id: int = Column(Integer, primary_key=True, index=True)
    name: str = Column(String(100), nullable=False)  # محدودیت طول 100 کاراکتر
    description: str = Column(String(255), nullable=True)  # محدودیت طول 255 کاراکتر
    price: float = Column(DECIMAL(10, 2), nullable=False)  # دقت بهتر برای مقادیر مالی
    stock: int = Column(Integer, default=0, nullable=False)  # مقدار پیش‌فرض و غیرقابل خالی

    def __repr__(self) -> str:
        return f"<Product(id={self.id}, name='{self.name}', price={self.price}, stock={self.stock})>"