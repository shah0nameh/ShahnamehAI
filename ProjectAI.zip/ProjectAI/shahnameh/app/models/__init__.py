from .user import User
from .poem import Poem

# در اینجا می‌توانید مدل‌ها را ثبت کنید
__all__ = ['User', 'Poem']