from .base_model import BaseModel, db

class User(BaseModel):
    __tablename__ = 'users'

    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    poems = db.relationship('Poem', backref='author', lazy=True)

    def __repr__(self):
        return f"<User {self.username}>"