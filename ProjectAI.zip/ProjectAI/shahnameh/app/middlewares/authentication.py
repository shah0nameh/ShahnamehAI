from fastapi import Request, HTTPException
from fastapi.security import HTTPBearer
from app.config.settings import settings
import jwt

security = HTTPBearer()

async def authentication_middleware(request: Request, call_next):
    token = request.headers.get("Authorization")
    if not token:
        raise HTTPException(status_code=401, detail="Authorization token is missing")

    try:
        # حذف "Bearer" از ابتدای توکن
        token = token.split(" ")[1]
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.JWT_ALGORITHM])
        request.state.user = payload  # کاربر را به درخواست اضافه می‌کنیم
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

    response = await call_next(request)
    return response