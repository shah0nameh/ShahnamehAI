import pytest
from exceptions import CustomError

def test_custom_error():
    with pytest.raises(CustomError):
        raise CustomError("An error occurred")