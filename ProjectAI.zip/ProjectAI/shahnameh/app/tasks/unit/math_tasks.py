def calculate_percentage(part: int, total: int) -> float:
    """
    محاسبه درصد.
    """
    if total == 0:
        return 0
    return (part / total) * 100