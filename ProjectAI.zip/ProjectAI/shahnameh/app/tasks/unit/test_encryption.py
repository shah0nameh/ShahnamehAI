from encryption import encrypt_data, decrypt_data

def test_encrypt_decrypt():
    data = "secret"
    encrypted = encrypt_data(data)
    decrypted = decrypt_data(encrypted)
    assert decrypted == data