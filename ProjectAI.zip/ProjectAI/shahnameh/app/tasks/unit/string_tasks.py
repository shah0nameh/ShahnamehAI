def reverse_string(text: str) -> str:
    """
    معکوس کردن یک رشته.
    """
    return text[::-1]