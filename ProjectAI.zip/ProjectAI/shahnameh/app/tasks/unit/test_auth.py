import pytest
from auth import generate_token, verify_token

def test_generate_token():
    token = generate_token({"user_id": 1})
    assert token is not None

def test_verify_token():
    token = generate_token({"user_id": 1})
    payload = verify_token(token)
    assert payload["user_id"] == 1