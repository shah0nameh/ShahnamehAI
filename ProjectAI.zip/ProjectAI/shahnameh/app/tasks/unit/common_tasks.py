import time

def generate_timestamp() -> str:
    """
    تولید یک استامپ زمانی.
    """
    return time.strftime("%Y-%m-%d %H:%M:%S")