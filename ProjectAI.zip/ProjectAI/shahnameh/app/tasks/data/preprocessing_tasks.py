def clean_text(text: str) -> str:
    """
    حذف نویز و تمیزکاری متن.
    """
    return text.lower().strip()

def tokenize_text(text: str) -> list[str]:
    """
    توکنایز کردن متن به لیستی از کلمات.
    """
    return text.split()