import requests

BASE_URL = "http://localhost:8000"

def test_product_creation():
    response = requests.post(f"{BASE_URL}/products", json={"name": "Sample Product", "price": 100})
    assert response.status_code == 201

def test_product_list():
    response = requests.get(f"{BASE_URL}/products")
    assert response.status_code == 200
    assert isinstance(response.json(), list)