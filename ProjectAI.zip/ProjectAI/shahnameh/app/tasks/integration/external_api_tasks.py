import requests

def fetch_poem_from_api(endpoint: str) -> dict:
    """
    واکشی اطلاعات شعر از یک API خارجی.
    """
    response = requests.get(endpoint)
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"خطا در واکشی داده‌ها: {response.status_code}")