import requests

BASE_URL = "http://localhost:8000"

def test_user_creation():
    response = requests.post(f"{BASE_URL}/users", json={"username": "test", "password": "test"})
    assert response.status_code == 201

def test_user_login():
    response = requests.post(f"{BASE_URL}/login", json={"username": "test", "password": "test"})
    assert response.status_code == 200
    assert "token" in response.json()