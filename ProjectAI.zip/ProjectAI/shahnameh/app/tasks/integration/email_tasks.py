from app.services.email_service import EmailService

def send_poem_notification(email: str, poem_title: str) -> None:
    """
    ارسال اطلاع‌رسانی در مورد شعر جدید به کاربران.
    """
    subject = f"شعر جدید: {poem_title}"
    body = f"شعر جدیدی با عنوان '{poem_title}' به شاهنامه اضافه شده است."
    EmailService.send_email(to_email=email, subject=subject, body=body)