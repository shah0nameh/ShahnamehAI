def translate_text(text: str, target_language: str) -> str:
    """
    ترجمه متن به زبان موردنظر با استفاده از یک سرویس شخص ثالث.
    """
    # فرض کنید این تابع با یک API ترجمه کار می‌کند
    translated_text = f"[ترجمه به {target_language}] {text}"
    return translated_text