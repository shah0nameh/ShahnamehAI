class BaseCustomException(Exception):
    """
    کلاس پایه برای استثناهای سفارشی پروژه.
    """
    def __init__(self, message: str, status_code: int):
        """
        مقداردهی اولیه برای استثناهای سفارشی.
        :param message: پیام خطا
        :param status_code: کد وضعیت HTTP مرتبط با خطا
        """
        super().__init__(message)
        self.message = message
        self.status_code = status_code

    def to_dict(self) -> dict:
        """
        تبدیل اطلاعات خطا به فرمت دیکشنری.
        :return: دیکشنری شامل پیام خطا و کد وضعیت
        """
        return {"error": self.message, "status_code": self.status_code}


class AuthenticationError(BaseCustomException):
    """
    خطای مرتبط با احراز هویت.
    """
    def __init__(self, message="Authentication failed"):
        super().__init__(message, status_code=401)


class AuthorizationError(BaseCustomException):
    """
    خطای مرتبط با مجوز دسترسی.
    """
    def __init__(self, message="Access denied"):
        super().__init__(message, status_code=403)


class ResourceNotFoundError(BaseCustomException):
    """
    خطای مربوط به عدم یافتن منبع.
    """
    def __init__(self, message="Resource not found"):
        super().__init__(message, status_code=404)


class ValidationError(BaseCustomException):
    """
    خطای مربوط به اعتبارسنجی داده‌ها.
    """
    def __init__(self, message="Invalid input data"):
        super().__init__(message, status_code=422)


class ConflictError(BaseCustomException):
    """
    خطای مرتبط با وجود تضاد (مانند تلاش برای ایجاد منبع تکراری).
    """
    def __init__(self, message="Conflict error"):
        super().__init__(message, status_code=409)


class InternalServerError(BaseCustomException):
    """
    خطای داخلی سرور.
    """
    def __init__(self, message="An unexpected error occurred"):
        super().__init__(message, status_code=500)