---

### **2. سند Docker: `DOCKER_GUIDE.md`**

این سند شامل دستورات لازم برای اجرای پروژه با Docker است.

```markdown
# Docker Guide

این راهنما شامل مراحل و دستورات لازم برای اجرای پروژه با Docker است.

---

## **1. پیش‌نیازها**
- Docker نسخه 20.10 یا بالاتر
- Docker Compose (اختیاری برای مدیریت چندین سرویس)

---

## **2. ساخت و اجرای Docker**

### **ساخت Docker Image**
برای ساخت تصویر Docker:
```bash
docker build -t project-name .



اجرای Docker Container
برای اجرای کانتینر:

docker run -d -p 8000:8000 --name project-container project-name

3. مدیریت کانتینرها
مشاهده کانتینرهای در حال اجرا

docker ps

مشاهده لاگ‌های کانتینر

docker logs -f project-container

توقف کانتینر

docker stop project-container

حذف کانتینر

docker rm project-container

4. استفاده از Docker Compose (اختیاری)
ایجاد فایل `docker-compose.yml`
یک فایل به نام docker-compose.yml ایجاد کرده و محتوای زیر را اضافه کنید:


version: '3.8'
services:
  app:
    build: .
    ports:
      - "8000:8000"
    environment:
      - FLASK_ENV=production
      
      اجرای پروژه با Docker Compose
برای اجرای پروژه

docker-compose up -d

5. نکات تکمیلی
برای بهینه‌سازی تصویر Docker، از فایل .dockerignore استفاده کنید و فایل‌های غیرضروری مانند venv/ و __pycache__/ را حذف کنید.


