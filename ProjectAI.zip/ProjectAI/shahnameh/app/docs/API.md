---

### **3. API.md**
این فایل برای مستندات API استفاده می‌شود.

#### محتوا:
```markdown
# API Documentation

## Endpoints

### Authentication
- **POST /api/v1/auth/login**
  - **Description**: Authenticate a user.
  - **Body**:
    ```json
    {
      "username": "user",
      "password": "pass"
    }
    ```
  - **Response**:
    ```json
    {
      "token": "jwt_token"
    }
    ```

- **POST /api/v1/auth/register**
  - **Description**: Register a new user.
  - **Body**:
    ```json
    {
      "username": "user",
      "email": "user@example.com",
      "password": "pass"
    }
    ```
  - **Response**:
    ```json
    {
      "id": 1,
      "username": "user",
      "email": "user@example.com"
    }
    ```

## User Management
- **GET /api/v1/users**
  - **Description**: Retrieve a list of users.
  - **Parameters**: None.
  - **Response**:
    ```json
    [
      {
        "id": 1,
        "username": "user1",
        "email": "user1@example.com"
      },
      {
        "id": 2,
        "username": "user2",
        "email": "user2@example.com"
      }
    ]
    ```