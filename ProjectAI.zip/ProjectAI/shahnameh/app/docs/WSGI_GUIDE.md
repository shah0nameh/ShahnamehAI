---

### **3. سند WSGI: `WSGI_GUIDE.md`**

این سند شامل راهنمای استقرار پروژه با WSGI (مانند Gunicorn یا uWSGI) است.

```markdown
# WSGI Guide

این راهنما شامل مراحل اجرای پروژه با استفاده از WSGI است.

---

## **1. نصب ابزارهای WSGI**

### **نصب Gunicorn**
```bash
pip install gunicorn


نصب uWSGI (اختیاری

pip install uwsgi


2. اجرای پروژه با Gunicorn
اجرای پروژه
برای اجرای پروژه با Gunicor

gunicorn -w 4 -b 0.0.0.0:8000 app:server


-w 4: تعداد پردازشگرها (workers).
-b 0.0.0.0:8000: آدرس و پورت برای سرویس‌دهی.
3. تنظیمات پیشرفته Gunicorn
ایجاد فایل پیکربندی
یک فایل به نام gunicorn.conf.py ایجاد کنید:


bind = "0.0.0.0:8000"
workers = 4
accesslog = "-"
errorlog = "-"
loglevel = "info"

اجرای Gunicorn با فایل پیکربندی

gunicorn -c gunicorn.conf.py app:server

4. اجرای پروژه با uWSGI
دستور اجرای uWSGI

uwsgi --http :8000 --module app:server --processes 4 --threads 2

5. نکات تکمیلی
برای استقرار در سرورهای تولیدی، از Nginx به عنوان یک Reverse Proxy استفاده کنید.
برای بهبود عملکرد، پیکربندی‌های Gunicorn یا uWSGI را مطابق نیاز پروژه خود تنظیم کنید.


---

### **جمع‌بندی:**

- سه سند جداگانه با نام‌های `DASH_GUIDE.md`، `DOCKER_GUIDE.md` و `WSGI_GUIDE.md` ایجاد کنید.
- هر سند شامل تمامی جزئیات مربوط به موضوع خود است.
- این اسناد را در پوشه `docs/` ذخیره کنید تا به راحتی در دسترس باشند.

اگر نیاز به تغییرات یا جزئیات بیشتری دارید، اطلاع دهید!