import re

def clean_text(text: str) -> str:
    """
    حذف نویز و تمیز کردن متن.
    """
    return re.sub(r"[^\w\s]", "", text).lower().strip()

def tokenize_text(text: str) -> list[str]:
    """
    توکنایز کردن متن به کلمات.
    """
    return text.split()

def remove_stopwords(text: str, stopwords: list[str]) -> str:
    """
    حذف کلمات توقف از متن.
    """
    words = text.split()
    return " ".join(word for word in words if word not in stopwords)