from datetime import datetime, timedelta

class DateTimeUtils:
    """کلاس ابزارهای مدیریت تاریخ و زمان."""

    @staticmethod
    def get_current_datetime():
        """
        برگرداندن تاریخ و زمان فعلی.
        """
        return datetime.now()

    @staticmethod
    def format_datetime(dt: datetime, format: str = "%Y-%m-%d %H:%M:%S") -> str:
        """
        قالب‌بندی تاریخ به فرمت مشخص.

        :param dt: شیء تاریخ و زمان
        :param format: فرمت مورد نظر (پیش‌فرض: "%Y-%m-%d %H:%M:%S")
        :return: تاریخ قالب‌بندی شده به صورت رشته
        """
        return dt.strftime(format)

    @staticmethod
    def add_days_to_date(days: int, base_date: datetime = None) -> datetime:
        """
        اضافه کردن تعداد روز به تاریخ مشخص.

        :param days: تعداد روزهایی که باید اضافه شوند
        :param base_date: تاریخ پایه (پیش‌فرض: تاریخ و زمان فعلی)
        :return: تاریخ جدید
        """
        if base_date is None:
            base_date = datetime.now()
        return base_date + timedelta(days=days)

    @staticmethod
    def days_between_dates(date1: datetime, date2: datetime) -> int:
        """
        محاسبه تعداد روز بین دو تاریخ.

        :param date1: تاریخ اول
        :param date2: تاریخ دوم
        :return: تعداد روزها به صورت عدد صحیح
        """
        return abs((date2 - date1).days)

    @staticmethod
    def get_current_date(format: str = "%Y-%m-%d") -> str:
        """
        دریافت تاریخ فعلی به صورت فرمت‌شده.

        :param format: فرمت مورد نظر (پیش‌فرض: "%Y-%m-%d")
        :return: تاریخ فعلی به صورت رشته
        """
        return datetime.now().strftime(format)