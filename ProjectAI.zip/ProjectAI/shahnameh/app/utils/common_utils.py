import random
import string

def generate_random_string(length: int = 8) -> str:
    """
    تولید یک رشته تصادفی با طول مشخص.
    """
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

def is_empty(value: str) -> bool:
    """
    بررسی اینکه یک مقدار خالی است یا نه.
    """
    return not bool(value.strip())