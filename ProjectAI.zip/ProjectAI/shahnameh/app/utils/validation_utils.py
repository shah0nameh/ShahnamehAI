import re

def is_valid_email(email: str) -> bool:
    """
    بررسی معتبر بودن یک آدرس ایمیل.
    """
    pattern = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
    return re.match(pattern, email) is not None

def is_valid_url(url: str) -> bool:
    """
    بررسی معتبر بودن یک URL.
    """
    pattern = r"^(http|https)://[^\s/$.?#].[^\s]*$"
    return re.match(pattern, url) is not None