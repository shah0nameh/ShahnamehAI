import os
import shutil
from datetime import datetime, timedelta


class DateTimeUtils:
    """کلاس ابزارهای مدیریت تاریخ و زمان."""

    @staticmethod
    def get_current_datetime():
        """
        برگرداندن تاریخ و زمان فعلی.
        """
        return datetime.now()

    @staticmethod
    def format_datetime(dt: datetime, format: str = "%Y-%m-%d %H:%M:%S") -> str:
        """
        قالب‌بندی تاریخ به فرمت مشخص.

        :param dt: شیء تاریخ و زمان
        :param format: فرمت مورد نظر (پیش‌فرض: "%Y-%m-%d %H:%M:%S")
        :return: تاریخ قالب‌بندی شده به صورت رشته
        """
        return dt.strftime(format)

    @staticmethod
    def add_days_to_date(days: int, base_date: datetime = None) -> datetime:
        """
        اضافه کردن تعداد روز به تاریخ مشخص.

        :param days: تعداد روزهایی که باید اضافه شوند
        :param base_date: تاریخ پایه (پیش‌فرض: تاریخ و زمان فعلی)
        :return: تاریخ جدید
        """
        if base_date is None:
            base_date = datetime.now()
        return base_date + timedelta(days=days)

    @staticmethod
    def days_between_dates(date1: datetime, date2: datetime) -> int:
        """
        محاسبه تعداد روز بین دو تاریخ.

        :param date1: تاریخ اول
        :param date2: تاریخ دوم
        :return: تعداد روزها به صورت عدد صحیح
        """
        return abs((date2 - date1).days)

    @staticmethod
    def get_current_date(format: str = "%Y-%m-%d") -> str:
        """
        دریافت تاریخ فعلی به صورت فرمت‌شده.

        :param format: فرمت مورد نظر (پیش‌فرض: "%Y-%m-%d")
        :return: تاریخ فعلی به صورت رشته
        """
        return datetime.now().strftime(format)


class FileUtils:
    """کلاس ابزارهای مدیریت فایل و پوشه."""

    @staticmethod
    def create_directory(path: str) -> None:
        """
        ایجاد پوشه در مسیر مشخص.

        :param path: مسیر پوشه
        """
        os.makedirs(path, exist_ok=True)

    @staticmethod
    def delete_file(file_path: str) -> None:
        """
        حذف یک فایل مشخص.

        :param file_path: مسیر فایل
        """
        if os.path.exists(file_path):
            os.remove(file_path)

    @staticmethod
    def move_file(src: str, dest: str) -> None:
        """
        انتقال فایل از یک مسیر به مسیر دیگر.

        :param src: مسیر مبدا
        :param dest: مسیر مقصد
        """
        shutil.move(src, dest)

    @staticmethod
    def list_files_in_directory(directory: str, extension: str = None) -> list:
        """
        لیست کردن فایل‌های موجود در یک پوشه با فیلتر پسوند.

        :param directory: مسیر پوشه
        :param extension: پسوند فایل (اختیاری)
        :return: لیستی از نام فایل‌ها
        """
        if not os.path.exists(directory):
            return []
        files = os.listdir(directory)
        if extension:
            return [f for f in files if f.endswith(extension)]
        return files

    @staticmethod
    def read_file(file_path: str) -> str:
        """
        خواندن محتوای فایل متنی.

        :param file_path: مسیر فایل
        :return: محتوای فایل به صورت رشته
        """
        with open(file_path, "r", encoding="utf-8") as file:
            return file.read()

    @staticmethod
    def write_to_file(file_path: str, content: str) -> None:
        """
        نوشتن محتوا در فایل متنی.

        :param file_path: مسیر فایل
        :param content: محتوای متن
        """
        with open(file_path, "w", encoding="utf-8") as file:
            file.write(content)