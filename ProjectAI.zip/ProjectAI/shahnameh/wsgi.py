from app.main import app

# WSGI application
application = app